#!/bin/sh

if [ -z "$1" ]; then
  echo "Enter credentials to access monitoring, to generate a token."
  read -p "Input login[s-camera]:" login_name
  [ -z "$login_name" ] && login_name="s-camera"
  read -s -p "Input password:" password

  request='
  {
	"jsonrpc":"2.0",
	"method":"user.login",
	"id":1,
	"auth":null,
	"params":{
	  "user":"'$login_name'",
	  "password":"'$password'"
	}
  }'

else
  file_request="$1"
  request=`cat $file_request | tr -d '\t\n '`
fi

http_head="Content-Type: application/json-rpc" 
link=http://monitoring.vz/zabbix/api_jsonrpc.php 

curl -d `tr -d '\t\n ' <<< $request` -X POST -H "$http_head" $link | jq '.'

