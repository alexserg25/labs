#!/usr/bin/env python3
# -*- coding: utf-8 -*-
try:
  import requests
except ImportError:
  print("Library \"requests\" not installed")
  exit()

import re

from json import dumps

url = "http://monitoring.vz/zabbix/api_jsonrpc.php"
headers = {"Content-Type": "application/json-rpc"}
# s-camera
token = "b88f2cba8cd5fb518dcb5369cc7bd9dc"
# For admin user
#token = "03ba3fa0235bf9436ddb41c52863b8d5"
method = "problem.get"

data = {
  "jsonrpc": "2.0",
  "id": 1,
  "auth": token,
  "method": method,
  "params":{
        "output": "extend",
        "actionids": "3"
  }
}
print(data)
print(str(data).replace("'", '"'))
print(dumps(data))

response = requests.post(url, data = str(data).replace('\'', '"'), headers = headers)
print(response.json())

data = '''
{
  "jsonrpc": "2.0",
  "id": 1,
  "auth": "03ba3fa0235bf9436ddb41c52863b8d5",
  "method": "problem.get",
  "params":{
        "output": "extend",
        "actionids": "3"
  }
}'''

print(re.sub('\s|\t|\n', '', data))
response = requests.post(url, data = data, headers = headers)
#print(response.text)

def main():
  print("Hello world")
    

if __name__ == "__main__":
  main()
